﻿using System.Web.UI;

namespace ApexWebForms.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}