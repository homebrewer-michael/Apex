﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ApexWebForms.Startup))]
namespace ApexWebForms
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
