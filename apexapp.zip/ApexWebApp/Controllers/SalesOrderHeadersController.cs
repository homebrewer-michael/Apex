﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ApexWebApp.Models;

namespace ApexWebApp.Controllers
{
    public class SalesOrderHeadersController : Controller
    {
        private SalesOrderHeaderContext db = new SalesOrderHeaderContext();

        SalesOrderHeader myData = new SalesOrderHeader
        {
            SalesOrderID = 1,
            SalesOrderNumber = "12344",
            PurchaseOrderNumber = "ADB3333",
            AccountNumber = "3334441"
        };


    // GET: SalesOrderHeaders
    public ActionResult Index()
        {
            //return View(db.SalesOrders.ToList());


            //return View(myData);
            return View();
        }

        public ActionResult Apex()
        {
            return View();
            //return View(myData);
        }

        // GET: SalesOrderHeaders/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SalesOrderHeader salesOrderHeader = db.SalesOrders.Find(id);
            if (salesOrderHeader == null)
            {
                return HttpNotFound();
            }
            return View(salesOrderHeader);
        }

        // GET: SalesOrderHeaders/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: SalesOrderHeaders/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,OrderDate,DueDate,SalesOrderNumber,PurchaseOrderNumber,AccountNumber")] SalesOrderHeader salesOrderHeader)
        {
            if (ModelState.IsValid)
            {
                db.SalesOrders.Add(salesOrderHeader);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(salesOrderHeader);
        }

        // GET: SalesOrderHeaders/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SalesOrderHeader salesOrderHeader = db.SalesOrders.Find(id);
            if (salesOrderHeader == null)
            {
                return HttpNotFound();
            }
            return View(salesOrderHeader);
        }

        // POST: SalesOrderHeaders/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,OrderDate,DueDate,SalesOrderNumber,PurchaseOrderNumber,AccountNumber")] SalesOrderHeader salesOrderHeader)
        {
            if (ModelState.IsValid)
            {
                db.Entry(salesOrderHeader).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(salesOrderHeader);
        }

        // GET: SalesOrderHeaders/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SalesOrderHeader salesOrderHeader = db.SalesOrders.Find(id);
            if (salesOrderHeader == null)
            {
                return HttpNotFound();
            }
            return View(salesOrderHeader);
        }

        // POST: SalesOrderHeaders/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            SalesOrderHeader salesOrderHeader = db.SalesOrders.Find(id);
            db.SalesOrders.Remove(salesOrderHeader);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
